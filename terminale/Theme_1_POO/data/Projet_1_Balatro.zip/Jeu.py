from Paquet import Paquet
from MainJoueur import MainJoueur
from Carte import Joker


class Jeu:
    def __init__(self):
        # TODO : initialiser le paquet puis le mélanger.
        # Initisaliser la main du joueur et ajouter un score qui sera initialisé à 0.
        pass

    def start(self):
        # TODO : Piocher 5 cartes, puis les ajouter à la main du joueur.
        pass
        

    def utiliser_joker(self):
        # TODO : permet d'utiliser un joker pour modifier soit la valeur et couleur d'une carte.
        pass

    def echanger_carte(self, nb_max_echanges=5):
        # Permet d'échanger jusqu'à 5 cartes.
        for i in range(nb_max_echanges):
            print("\nÉchange n°", i+1 "/", nb_max_echanges)
            print("\nVotre main :", self.main_joueur)   
            # TODO : utiliser un input pour demander aux joueurs quelle carte échanger 
            # TODO : remplacer 1 carte par 1 nouvelle carte avec la méthode Paquet.piocher(1)
            pass

            print("Nouvelle main :", self.main_joueur)

    def calculer_score(self, combinaison):
        # Attribue un score en fonction de la combinaison obtenue.
        scores = {
            "Rien": 0, "Paire": 10, "Double Paire": 20, "Brelan": 30,
            "Suite": 40, "Couleur": 50, "Full": 60, "Carré": 80,
            "Quinte Flush": 100, "Quinte Flush Royale": 200
        }
        # la méthode get() permet ed récupérer la valeur d'une clef
            #ex : clef : "Full" || valeur : 60 || get("Full") => 60
        self.score = self.score + scores.get(combinaison)

    def jouer(self):
        print("=== Bienvenue dans Mini-Balatro ===")
        # TODO : lancer le jeu avec start, puis définir le nombre de manche

        # TODO : (Fonctionnalité IA) Calcul des scores
        pass


# TODO : Lancer le jeu 
pass
