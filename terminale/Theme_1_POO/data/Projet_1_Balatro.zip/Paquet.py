import Carte
import random
# TODO : a vous d'importer votre classe Pile !!

class Paquet:
    """
    Attribution des valeurs et couleurs des 52 cartes qui constituent un paquet de jeu.
    """
    valeurs = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "V", "D", "R", "A"]
    couleurs = ["♠", "♥", "♦", "♣"]

    def __init__(self):
        self.cartes = []
        # TODO : initialiser un paquet avec la structure d'une Pile
        # associer un couple (tuple) (valeur, couleur) 
        # correspondant aux 52 cartes d'un paquet de jeu.
        # On stock chaque couple dans `self.paquet`.
        pass

    def melanger(self):
       """On dépile le paquet dans une liste, on mélange la liste, puis rempile les cartes.
        --> La méthode random.shuffle() ne fonctionne pas directement sur une pile."""
        # TODO : méthode pour mélanger le paquer
        pass

    def piocher(self, nb):
        # TODO : depiler les `nb` cartes du paquet
        # Cette méthode correspond à "dépiler", la pile de carte (le paquet)
        pass
    
    def __str__(self):
        # On créer une pile temporaire pour éviter de dépiler notre paquet entierement.
        auxiliaire = Pile()
        while not self.cartes.est_vide():
            auxiliaire.empiler(self.cartes.depiler())
        contenu_paquet = []
        while not auxiliaire.est_vide():
            carte = auxiliaire.depiler()
            contenu_paquet.append(str(carte))
            self.cartes.empiler(carte)
        return " ".join(contenu_paquet)

        
# Tests :   
if __name__ == "__main__":
    mon_paquet = Paquet()
    print(mon_paquet)
    mon_paquet.melanger()
    print("Paquet mélangé :", mon_paquet)
    carte_pioche = mon_paquet.piocher(3)
    print("Carte pioché :", carte_pioche)
    print("Paquet après pioche :", mon_paquet)