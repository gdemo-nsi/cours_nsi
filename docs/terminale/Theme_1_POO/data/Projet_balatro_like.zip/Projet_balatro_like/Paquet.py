import Carte
import random

class Paquet:
    """
    Attribution des valeurs et couleurs des 52 cartes qui constituent un paquet de jeu.
    """
    valeurs = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "V", "D", "R", "A"]
    couleurs = ["♠", "♥", "♦", "♣"]

    def __init__(self):
        self.cartes = []
        # TODO : associer un couple (tuple) (valeur, couleur) 
        # correspondant aux 52 cartes d'un paquet de jeu.
        # On stock chaque couple dans `cartes`.
        pass

    def melanger(self):
        # TODO : méthode pour mélanger le paquer
        pass

    def piocher(self, nb):
        # TODO : retirer les `nb` cartes du paquet
        # Indice [:nb] permet d'accéder aux nb premier éléments d'une liste
        # Indeice [nb:] permet d'accéder aux nb dernier éléments d'une liste
        # cf. Slice python : https://blog.stephane-robert.info/docs/developper/programmation/python/slicing/
        pass
    
    def __str__(self):
        # Affiche d'un ensemble par compréhension
        contenu_paquet = [str(carte) for carte in self.cartes]
        return " ".join(contenu_paquet)

        
    
if __name__ == "__main__":
    mon_paquet = Paquet()
    print(mon_paquet)
    mon_paquet.melanger()
    print("Paquet mélangé :", mon_paquet)
    carte_pioche = mon_paquet.piocher(3)
    print("Carte pioché :", carte_pioche)
    print("Paquet après pioche :", mon_paquet)