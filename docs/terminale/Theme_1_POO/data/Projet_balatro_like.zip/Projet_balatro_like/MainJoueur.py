class MainJoueur:
    def __init__(self):
        self.cartes = []

    def ajouter_cartes(self, cartes):
        # TODO : ajouter les cartes piochées à l'objet MainJoueur
        # La méthode extend() permet d'ajouter plusieurs éléments à une liste
        # Cf. https://www.w3schools.com/python/ref_list_extend.asp
        pass

    def evaluer_combinaison(self):
        # TODO : En vous aidant de l'IA de votre choix, 
        # réaliser une méthode de vérification de combinaison de main de poker (https://fr.wikipedia.org/wiki/Main_au_poker)
        # 🚨M'appeler avant d'exécuter votre prompt🚨
        # 🚨Méthode à réaliser à la fin du projet afin qu'il puisse s'adapter à vos méthodes🚨
        pass
    
    def __str__(self):
        return " ".join(str(carte) for carte in self.cartes)
    