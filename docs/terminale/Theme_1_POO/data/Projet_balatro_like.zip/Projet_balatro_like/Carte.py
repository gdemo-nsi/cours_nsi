# ----- Classe Carte -----
class Carte:
    """
    Carte possédant une valeur et une couleyr (non défini pour le moment)
    """
    # TODO : constructeur à définir pour attribuer une valeur et couleur à une carte
    pass
    
    # Méthode pour afficher une carte
    def __str__(self):
        return f"{self.valeur}{self.couleur}"
    
# ----- Classe Joker ----- Heritage : Classe Carte
class Joker(Carte):
    # TODO : méthode pour modifier la valeur d'une carte
    def modifier_valeur(self, valeur):
        pass

    #TODO : méthode pour modifier la couleur d'une carte
    def modifier_couleur(self, couleur):
        pass

    def __str__(self):
        return f"{self.valeur}{self.couleur}"
 
# Le main permet de tester les différentes fonctionnalités crées au sein du fichier.  
if __name__ == "__main__":
    ma_carte = Carte(2,"♠")
    print(ma_carte) # Affiche l'instance de Carte grâce à la méthode __str__